<?php

header('Content-type: text/css; charset:UTF-8');

?>

body
{
    margin: 0;
    padding: 0;
    
    background-image: url(../images/2.jpg);
    background-repeat: no-repeat;
    background-size: cover;
}