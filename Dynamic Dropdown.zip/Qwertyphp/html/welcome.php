
<?php
$link = mysqli_connect("localhost:3307", "root", "");
mysqli_select_db($link, "Sub_Directories");
?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="/css/style.php">
    </head>
    <body style="background-image:url(/images/2.jpg); background-repeat: no-repeat; background-size: cover">
        <div class="dropdown">
        <form name="dropdown" action="" method="post">
            <select>
                <option>Sub Directories </option>
                <?php
                $res = mysqli_query($link, "SELECT * FROM directories");
                while($row = mysqli_fetch_array($res))
                {
                ?>
                    <option><?php echo $row["dir_name"];?></option>
                <?php
                }
                ?>
                
            </select>
            
        </form>
        </div>
    
    </body>
</html>