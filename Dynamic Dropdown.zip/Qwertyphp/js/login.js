let name="";

function validate()
{
    let user = document.Login.username.value;
    let pass = document.Login.password.value;
    let valid = false;
    let username_array = ["saurav", "shivam", "huzaifa"];
    let password_array = ["Qwerty", "12345", "sikora"];
    for(let i = 0; i < username_array.length; i++)
        {
            if((user == username_array[i]) && (pass == password_array[i]))
                {
                    name = username_array[i];
                    valid = true;
                    break;
                }
        }
    if(valid==true)
        {
            window.location = "../html/welcome.php";
            alert("Welcome "+ name);
            return false;

            
        }
    else
        {
            alert("Wrong Username or Password");
        }
}

function getName()
{
    sessionStorage.setItem('id', name);
    let val = sessionStorage.getItem('id');
    console.log(val);
}